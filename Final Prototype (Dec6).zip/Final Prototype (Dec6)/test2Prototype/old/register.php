<!DOCTYPE html>
<html>
<head>
	<title>Registration page</title>
	<style>
		form{padding-top: 120px;
			text-align:center;
		font-size:30px;}
		input{width: 250px;
		height: 40px;
		font-size: 30px;}
	</style>
</head>
<body>
<form method="post" action="connect.php">
Username : <input type="text" name="username"><br><br>
Password : <input type="password" name="password"><br><br>
<input type="submit" value="Submit">
</form>
	
<br><br>
<a href="login.php">
    <button>Return to login page</button>
</a>

</body>
</html>

<!-- https://www.youtube.com/watch?v=OHjkg_rifTw 
https://www.codeandcourse.com/how-to-connect-html-form-to-mysql-database-using-php-in-4-minutes/
-->