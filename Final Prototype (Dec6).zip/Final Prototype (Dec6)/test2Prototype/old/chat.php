<head>
	<title>Chatroom</title>
	<style>
		form{padding-top: 120px;
			text-align:center;
		font-size:30px;}
		input{width: 250px;
		height: 40px;
		font-size: 30px;}
	</style>
</head>
<b>Default Chatroom: proof of concept only</b><br><br>
		
<a href="login.php">
    <button>Logout</button>
</a>
<br><br>
<a href="team.php">
    <button>View Teams</button>
</a>
<br><br>
<a href="homepage.php">
    <button>Leave Chat</button>
</a>