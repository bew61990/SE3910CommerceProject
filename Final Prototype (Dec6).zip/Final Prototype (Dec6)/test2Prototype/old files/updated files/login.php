<head>
	<title>Login page</title>
	<style>
		form{padding-top: 120px;
			text-align:center;
		font-size:30px;}
		input{width: 250px;
		height: 40px;
		font-size: 30px;}
	</style>
</head>
<div class="wrapper">
	<div class="container">
		<h1>Welcome</h1>
		
		<form action ="homepage.php" class="form">
			<input autofocus type="text" placeholder="Username">
			<input type="password" placeholder="Password">
			<button type="submit" id="login-button">Login</button>
		</form>
		<br><br>
		<a href="register2.php">
			<button>Click here to register</button>
		</a>
		
	</div>

</div>
	<!--does not currently check database to check for login info, just goes to homepage-->
	<!--/*code derrived from: https://codepen.io/Lewitje/pen/BNNJjo */ -->