<?php
   include('session.php');
?>

<head>
	<title>Homepage</title>
	<style>
		form{padding-top: 120px;
			text-align:center;
		font-size:30px;}
		input{width: 250px;
		height: 40px;
		font-size: 30px;}
	</style>
</head>
<b>Default Homepage: proof of concept only</b><br><br>

 <body>
      <h1>Welcome <?php echo $_COOKIE['user']; ?></h1> 
      <h2><a href = "logout.php">Sign Out</a></h2>
   </body>


<br><br>
<a href="team.php">
    <button>View Teams</button>
</a>
<br><br>
<a href="chat.php">
    <button>Join Chat</button>
</a>