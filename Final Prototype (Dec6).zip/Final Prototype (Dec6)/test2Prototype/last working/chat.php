<?php
   include('session.php');
?>

<head>
	<title>Chatroom</title>
	<style>
		form{padding-top: 120px;
			text-align:center;
		font-size:30px;}
		input{width: 250px;
		height: 40px;
		font-size: 30px;}
	</style>
</head>
<b>Default Chatroom: proof of concept only</b><br><br>
		
		

 <body>
      <h1>Join the chat <?php echo $_COOKIE['user']; ?></h1> 
      <h2><a href = "logout.php">Sign Out</a></h2>
   </body>		
		


<br><br>
<a href="team.php">
    <button>View Teams</button>
</a>
<br><br>
<a href="homepage.php">
    <button>Leave Chat</button>
</a>