<?php
	$unmae = $_REQUEST['uname'];
	$msg = $_REQUEST['msg'];
	$conn = mysql_connect("localhost", "root", "");
	mysql_select_db('chatbox',$conn);
	$insert = "INSERT logs SET
							username='$uname',
							msg='$msg'
							";
	mysql_query($insert);
	
?>