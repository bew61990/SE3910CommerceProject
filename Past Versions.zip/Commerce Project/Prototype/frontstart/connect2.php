<?php
$username = filter_input(INPUT_POST, 'username');
$password = filter_input(INPUT_POST, 'password');
$email = filter_input(INPUT_POST, 'email');
if (!empty($username)){
if (!empty($password)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";//change these to be appropriate to your setup
#$dbpassword = "root";//change these to be appropriate to your setup
$dbname = "sportschatapp"; // the overall database
//create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);


if (mysqli_connect_error()){
die('Connect Error ('.mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO users (username, pass, email)
values ('$username',SHA2('$password',256),'$email')";
if ($conn->query($sql)){
echo "New record is inserted successfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Password should not be empty";
die();
}
}
else{
echo "Username should not be empty";
die();
}
?>
<br><br><br>

<?php header("login2.php"); ?>

<a href="login2.php">
    <button>Click here to return to login</button>
</a>