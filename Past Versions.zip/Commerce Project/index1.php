<html>
	<head>
		<title>Live Chat</title>
		<script src="" type="text/javascript"></script>
		<script>
			function submitChat(){
				if( form1.uname.value == '' || form1.msg.value == ''){
					alert("All fields are mandatory!");
				}
				form1.uname.readyState = true;
				form1.uname.style.border='none';
				$('#imageload').show();
				uname = encodeURIComponent(form1.uname.value);
				var msg = encodeURIComponent(form1.msg.value);
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function(){
					if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
						document.getElementById('chatlogs').innerHTML = xmlhttp.responseText;
						$('#imageload').hide();
					}
				}
				xmlhttp.open('GET','insert.php?uname='+uname+'&msg='+msg,true);
				xmlhttp.send();
			}
			$(documet).ready(function(e){
				$.ajaxSetup({cache:false});
				serInterval(function(){$('#chatlogs').load('logs.php');},2000);
			});
		</script>
	</head>
	<body style="background:lightblue">
		<div align="center">
			<form name="form1">
				Enter your tag:<input type="text" name="uname"><br>
				Your message:<textarea name="msg"></textarea><br>
				<a href="#" onclick="submitChat()">Send</a><br><br><br>
				<div id="imageload" style="display:none">
					<img src="#" width="100">
				</div>
			<div id="chatlogs">
				Loading chatlog please wait.....<img src="#" width="100">
			</div>
			</form>
		</div>
	</body>
</html>	